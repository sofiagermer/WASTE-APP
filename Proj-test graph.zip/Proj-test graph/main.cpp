#include <iostream>
#include "Graph.h"
#include "Algorithms/Analysis.h"
#include <memory>
#include <string>
#include <stdexcept>

using namespace std;

void make(int n);

int main() {
    //Graph graph("C:/Users/Rafae/Desktop/School_I_guess/2_ano/2_semestre/CAL/Proj-test graph/Map/outputTarjan/processedNodes.txt","C:/Users/Rafae/Desktop/School_I_guess/2_ano/2_semestre/CAL/Proj-test graph/Map/outputTarjan/processedEdges.txt");
/*    ifstream file("Map/porto_full_nodes_xy.txt");
    int num;
    file >> num;
    cout << num << endl;
*/
    //cout << graph.getVertexSet().size() << endl;
    /*
    for(auto v : graph.getVertexSet()){
        cout << v->getX() << endl;
    }*/
/*
    Analysis::dijkstraAnalysis(&graph);
    Analysis::aStarAnalysis(&graph);
    Analysis::aStarVsDijkstra(&graph);
    */
    //make(100);

    //make(50);
    /*
    cout << "Reading 100x100" << endl;
    Graph graph100x100("../Map/100x100/nodes.txt", "../Map/100x100/edges.txt");

    cout << "Reading 50x50" << endl;
    Graph graph50x50("../Map/50x50/nodes.txt", "../Map/50x50/edges.txt");
*/

    /*
    cout << "Reading espinho" << endl;
    Graph graphEspinho("../Map/espinho_strong_nodes_xy.txt", "../Map/espinho_strong_edges.txt");
    cout << "Reading penafiel" << endl;
    Graph graphPenafiel("../Map/penafiel_strong_nodes_xy.txt", "../Map/penafiel_strong_edges.txt");*/
    /*
    cout << "Reading porto" << endl;
    Graph graph("../Map/outputTarjan/processedNodes.txt","../Map/outputTarjan/processedEdges.txt");*/
/*
    cout << "time taken penafiel" << endl;
    Analysis::aStarVsDijkstraFixed(&graphPenafiel);
    cout << "time taken espinho" << endl;
    Analysis::aStarVsDijkstraFixed(&graphEspinho);*/
/*
    cout << "time taken 50x50" << endl;
    Analysis::aStarVsDijkstraFixed(&graph50x50);*/
/*
    cout << "time taken porto" << endl;
    Analysis::aStarVsDijkstraFixed(&graph);*/
/*
    cout << "time taken 100x100" << endl;
    Analysis::aStarVsDijkstraFixed(&graph100x100);*/


    //Analysis::preprocessingAnalysisKosaraju();
    Analysis::preprocessingAnalysisTarjan();

    std::cout << "End program" << std::endl;
    return 0;
}


void nodes(int n){
    char filepath[128];
    sprintf(filepath, "C:/Users/Rafae/Desktop/School_I_guess/2_ano/2_semestre/CAL/Proj-test graph/Map/%dx%d/nodes.txt", n, n);
    ofstream file((string)filepath);
    file << (int) (n * n + 2 * n + 1) << endl;
    int v = 0;
    for(int i = 0; i < n + 1; i++){
        for(int j = 0; j < n + 1; j++){
            char s[20];
            sprintf(s, "(%d,%d,%d)", v, i, j);
            file << s << endl;
            v++;
        }
    }
    file.close();
}

void edges(int n){
    char filepath[128];
    sprintf(filepath, "C:/Users/Rafae/Desktop/School_I_guess/2_ano/2_semestre/CAL/Proj-test graph/Map/%dx%d/edges.txt", n, n);
    ofstream file((string) filepath);
    file << (int) (2 * n * n + 2 * n) << endl;
    int v = 0;
    for(int i = 0; i < n + 1; i++){
        for(int j = 0; j < n + 1; j++){
            if( j % (n + 1) != n){
                char s[20];
                sprintf(s, "(%d,%d)", v, v+1);
                file << s << endl;
            }
            if( i % (n + 1) != n){
                char s[20];
                sprintf(s, "(%d,%d)", v, v+n+1);
                file << s << endl;
            }
            v++;
        }
    }
    file.close();
}

void make(int n){
    cout << "beginning" << endl;
    nodes(n);
    edges(n);
    cout << "done making" << endl;
}