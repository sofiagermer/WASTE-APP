//
// Created by miguel on 21/05/21.
//

#ifndef WASTE_APP_CLUSTERING_H
#define WASTE_APP_CLUSTERING_H

#include "../Elements/Driver.h"
#include "../Elements/House.h"

class Clustering {
    /*vector<vector<Vertex*>> DBSCAN(vector<Driver> fleet,vector <House> housesToVisit){
        for(auto d:fleet){
            if(d.)
        }
        for(auto h:housesToVisit){

        }
    }*/
};


#endif //WASTE_APP_CLUSTERING_H
